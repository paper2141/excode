x = 10

def test():
    global x
    print("수정 전:", x)
    x = 20

test()
print("수정 후:", x)     