# 문제 4-1: 파일을 읽어 라인번호를 붙여 출력하고, ***.sav 파일로 저장
import os

while True:
    filename = input("읽을 파일명을 입력하세요 (종료: q): ")
    if filename == 'q':
        print("프로그램을 종료합니다.")
        break

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except FileNotFoundError:
        print(f"'{filename}' 파일이 없습니다. 다시 입력하세요.")
        continue

    # 1. 라인번호를 붙여 출력
    numbered = []
    for i, line in enumerate(lines, start=1):
        new_line = f"{i} {line.rstrip(chr(10))}"
        print(new_line)
        numbered.append(new_line + '\n')

    # 2. ***.sav 형식으로 저장 (예: test.txt -> test.sav)
    save_name = os.path.splitext(filename)[0] + '.sav'
    with open(save_name, 'w', encoding='utf-8') as f:
        f.writelines(numbered)
    print(f"'{save_name}' 파일로 저장했습니다.")
    break
