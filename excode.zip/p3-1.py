# 문제 3-1: 가변 개수의 정수와 연산자(op)를 받아 계산하는 함수

def calc(*nums, op='+'):
    """nums의 정수들을 op('+' 또는 '*')로 연산한 결과를 반환"""
    if op == '+':
        result = 0
        for n in nums:
            result += n
    elif op == '*':
        result = 1
        for n in nums:
            result *= n
    else:
        raise ValueError("op는 '+' 또는 '*'만 가능합니다.")

    # 실행 예처럼 계산식도 함께 출력
    print(f"{op.join(str(n) for n in nums)}={result}")
    return result


# 테스트
if __name__ == '__main__':
    r1 = calc(1, 1, 4, op='+')
    print("반환값:", r1)

    r2 = calc(1, 2, op='*')
    print("반환값:", r2)

    r3 = calc(2, 3, 4, 5, op='*')
    print("반환값:", r3)
