import math

a, b, c = 3, 4, 5
ans1 = 1 / (1 + (a / b) + c)
print(f"1번 정답: {ans1:.4f} (분수 형태: 4/27)")


a, b, c = 1, 1, -6
discriminant = b**2 - 4*a*c

x1 = (-b + math.sqrt(discriminant)) / (2 * a)
x2 = (-b - math.sqrt(discriminant)) / (2 * a)
print(f"2번 정답: 두 근은 {int(x1)}, {int(x2)}")


r = 5
ans3 = math.pi * (r ** 2)
print(f"3번 정답: {ans3:.4f} (파이 표현: 25π)")



beta = 2.0
g = 3.2
ans4 = beta * math.exp(-g)
print(f"4번 정답: {ans4:.4f}")


x = 0
mu = 1.5
sigma = 2.0

coeff = 1 / (sigma * math.sqrt(2 * math.pi))
exponent = -0.5 * (((x - mu) / sigma) ** 2)
ans5 = coeff * math.exp(exponent)

print(f"5번 정답: {ans5:.4f}")