def check_leap_year(year):
    # 400으로 나누어떨어지거나, 4로 나누어떨어지면서 100으로 나누어떨어지지 않는 경우
    if (year % 400 == 0) or (year % 4 == 0 and year % 100 != 0):
        print(f"{year}년은 윤년입니다")
    else:
        print(f"{year}년은 평년입니다")

check_leap_year(2024)
check_leap_year(2115)
check_leap_year(2012)