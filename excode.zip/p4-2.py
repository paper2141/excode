# 문제 4-2: 파일의 글자수(공백 제외), 단어 수, 라인 수 출력

filename = input("읽을 파일명을 입력하세요: ")

try:
    with open(filename, 'r', encoding='utf-8') as f:
        text = f.read()
except FileNotFoundError:
    print(f"'{filename}' 파일이 없습니다.")
else:
    # 공백(스페이스, 탭, 줄바꿈 등)을 제외한 글자수
    characters = 0
    for ch in text:
        if not ch.isspace():
            characters += 1

    # 공백으로 분리된 문자열 = 단어
    words = len(text.split())

    # \n으로 분리된 문자열 = 라인
    lines = len(text.splitlines())

    print(f"characters : {characters}")
    print(f"words : {words}")
    print(f"lines : {lines}")
