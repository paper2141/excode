# input() 2번 사용
a = int(input("첫 번째 정수를 입력하세요: "))
b = int(input("두 번째 정수를 입력하세요: "))

# format() 메서드 방식 출력
print("{} + {} = {}".format(a, b, a + b))
print("{} - {} = {}".format(a, b, a - b))
print("{} x {} = {}".format(a, b, a * b))
print("{} / {} = {}".format(a, b, a / b))