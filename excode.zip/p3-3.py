# 문제 3-3: 문자열에서 모음(a, e, i, o, u)의 개수 반환

def count_vowel(s):
    """문자열 s에 들어 있는 모음의 개수를 반환 (대소문자 구분 없음)"""
    count = 0
    for ch in s.lower():
        if ch in 'aeiou':
            count += 1
    return count


if __name__ == '__main__':
    text = input("문자열을 입력하세요: ")
    print("모음의 개수:", count_vowel(text))
