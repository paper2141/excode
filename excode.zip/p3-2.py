# 문제 3-2: 정수 리스트에서 (min, max)를 튜플로 반환

def min_max(numbers):
    """정수 리스트를 받아 (최솟값, 최댓값) 튜플 반환"""
    smallest = numbers[0]
    largest = numbers[0]
    for n in numbers[1:]:
        if n < smallest:
            smallest = n
        if n > largest:
            largest = n
    return (smallest, largest)


if __name__ == '__main__':
    data = input("정수들을 공백으로 구분하여 입력하세요: ")
    nums = [int(x) for x in data.split()]

    if not nums:
        print("입력된 정수가 없습니다.")
    else:
        mn, mx = min_max(nums)
        print("min:", mn)
        print("max:", mx)
