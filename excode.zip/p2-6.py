import math

for n in range(1, 101):
    if n < 2:
        continue

    is_prime = True

    for i in range(2, int(math.isqrt(n)) + 1):
        if n % i == 0:
            is_prime = False
            break

    if is_prime:
        print(f"{n}은 소수입니다")